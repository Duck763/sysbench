glmark2 2023.01 for arm64 Linux, self-contained with Mesa GPU drivers bundled.
Nothing needs to be installed.

Install
  tar xzf glmark2-2023.01-linux-arm64.tar.gz
  cd glmark2-2023.01-linux-arm64

Pick the launcher for your display setup and graphics API:

                        OpenGL              OpenGL ES 2.0
  X11 desktop           ./glmark2           ./glmark2-es2
                        ./glmark2-egl (OpenGL through EGL)
  Wayland desktop       ./glmark2-wayland   ./glmark2-es2-wayland
  No desktop, monitor   ./glmark2-drm       ./glmark2-es2-drm
  No monitor at all     ./glmark2-gbm       ./glmark2-es2-gbm

Most ARM boards are best tested with the OpenGL ES (es2) launchers. The drm
launchers need a monitor connected and no desktop running on it; run them
from a text console or over SSH. The gbm launchers render without any display.
For drm and gbm, your user needs access to /dev/dri (be root or in the
"video" and "render" groups).

Always run a launcher, not the files in bin/. To run one from any directory,
symlink it:
  sudo ln -s "$PWD/glmark2-es2-drm" /usr/local/bin/glmark2-es2-drm

Examples
  ./glmark2-es2                              full benchmark, prints a score
  ./glmark2-es2 --fullscreen
  ./glmark2-es2 -b shading:duration=5        one scene
  ./glmark2-es2 --off-screen                 render without showing frames
  ./glmark2-es2 --help

Check which driver is in use: the GL_RENDERER line printed at start-up. If it
says "llvmpipe", Mesa found no supported GPU and is rendering in software on
the CPU, so the score does not measure the GPU.

GPU drivers
  By default the launchers use the bundled Mesa drivers, which support
  Raspberry Pi (vc4, v3d), Mali (Panfrost, Panthor, Lima), Adreno (Freedreno),
  Vivante (Etnaviv), Apple (Asahi) and others, plus software rendering.

  If the machine has its own vendor driver (NVIDIA Jetson, or a proprietary
  Mali driver), use that instead:
    GLMARK2_SYSTEM_GL=1 ./glmark2-es2
  This mode needs glibc 2.35 or newer (Ubuntu 22.04 or newer, JetPack 6),
  and the system must provide the GL, X11/Wayland, libdrm, gbm and udev
  libraries for the launcher you use.
