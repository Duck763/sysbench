sysbench for arm64 Linux, self-contained. Nothing needs to be installed.

Install
  tar xzf sysbench-1.0.20-linux-arm64.tar.gz
  cd sysbench-1.0.20-linux-arm64
  ./sysbench --version

Always run the ./sysbench launcher, not bin/sysbench.bin. To run it from any
directory, symlink it:
  sudo ln -s "$PWD/sysbench" /usr/local/bin/sysbench

Examples
  ./sysbench cpu --threads=4 --time=10 run
  ./sysbench memory --threads=4 --time=10 run
  ./sysbench threads --time=10 run
  ./sysbench mutex run

  Disk test (run it in a directory on the disk you want to test):
    ./sysbench fileio --file-total-size=2G prepare
    ./sysbench fileio --file-total-size=2G --file-test-mode=rndrw --time=30 run
    ./sysbench fileio --file-total-size=2G cleanup

  Database test (the database must already exist; use the prepare, run and
  cleanup steps in that order):
    ./sysbench oltp_read_write --db-driver=mysql --mysql-host=HOST \
        --mysql-user=USER --mysql-password=PASS --mysql-db=sbtest \
        --tables=4 --table-size=10000 prepare

  For PostgreSQL, use --db-driver=pgsql with --pgsql-host, --pgsql-user,
  --pgsql-password and --pgsql-db.

The OLTP test scripts are in share/sysbench.
